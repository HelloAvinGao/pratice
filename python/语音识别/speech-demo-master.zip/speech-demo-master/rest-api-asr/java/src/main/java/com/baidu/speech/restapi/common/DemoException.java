package com.baidu.speech.restapi.common;

public class DemoException extends Exception {
    public DemoException(String message) {
        super(message);
    }
}
