module.exports = {
    language: {
      name: "英文",
    },
    navbar: {
      home: "Home",
      remember:"remember",
      register:"register",
      forgetpwd:"Forgot password",
      username:"username",
      password:"password",
      login:"log in",
      welcomeMsg:"Welcome to the best internal management website in the world!",
      inputUserNameAlert:"Please input your username!",
      inputPwdAlert:"Please input your Password!"

    },
  };