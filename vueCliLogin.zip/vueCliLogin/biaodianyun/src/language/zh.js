module.exports = {
  language: {
    name: "zh",
  },
  navbar: {
    home: "首页",
    remember:"记住我",
    register:"马上注册",
    forgetpwd:"忘记密码",
    username:"用户名",
    password:"密码",
    login:"登录",
    welcomeMsg:"欢迎来到世界上最好的公司内部管理网站!",
    inputUserNameAlert:"请输入用户名!",
    inputPwdAlert:"请输入密码!"
  },
};