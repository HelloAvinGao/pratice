<template>
  <a-layout id="components-layout-demo-custom-trigger">
    <a-layout-sider v-model="collapsed" :trigger="null" collapsible>
      <div class="logo" />
      <a-menu theme="dark" mode="inline" :default-selected-keys="['1']">
        <a-menu-item key="1">
          <router-link :to="{path:'/dashboard'}">
            <a-icon type="dashboard" />
            <span>dashboard</span>
          </router-link>
        </a-menu-item>
        <a-menu-item key="2">
          <router-link :to="{path:'/setting'}">
            <a-icon type="setting" />
            <span>setting</span>
          </router-link>
        </a-menu-item>
        <!-- <a-menu-item key="3">
          <router-link :to="{path:'/upload'}">
            <a-icon type="upload" />
            <span>upload</span>
          </router-link>
        </a-menu-item>
        <a-menu-item key="4">
          <router-link :to="{path:'/software'}">
            <a-icon type="appstore" />
            <span>software</span>
          </router-link>
        </a-menu-item> -->
      </a-menu>
    </a-layout-sider>
    <a-layout>
      <a-layout-header style="background: #fff; padding: 0;">
        <a-row>
          <a-col :span="1">
            <a-icon style="left:0;"
              class="trigger"
              :type="collapsed ? 'menu-unfold' : 'menu-fold'"
              @click="() => (collapsed = !collapsed)"
            />
          </a-col>
          <a-col :span="1" style="float:right;margin-right:2rem;">
            <a-dropdown>
              <a class="ant-dropdown-link" @click="e => e.preventDefault()">
                <a-avatar>{{ username }}</a-avatar>
              </a>
              <a-menu slot="overlay" style="margin-top:10px;">
                <a-menu-item>
                  <a href="javascript:;">1st menu item</a>
                </a-menu-item>
                <a-menu-item>
                  <a href="javascript:;">2nd menu item</a>
                </a-menu-item>
                <a-menu-item>
                  <a href="javascript:;" @click="cancelClick">注销</a>
                </a-menu-item>
              </a-menu>
            </a-dropdown>
          </a-col>
        </a-row>

       
      </a-layout-header>
      <a-layout-content
        :style="{ margin: '24px 16px 0px 16px', background: '#fff', minHeight: '280px' }"
      >
        <router-view></router-view>
      </a-layout-content>
    </a-layout>
  </a-layout>
</template>
<script>
export default {
  data() {
    return {
      collapsed: false,
      username: JSON.parse(localStorage.getItem('username'))
    };
  },
  methods: {
    cancelClick(){
      this.$router.replace("/login");
    }
  }
};
</script>
<style>
section{
  width:100%;
  height: 100%;
  margin:0;
  padding:0;
}
#components-layout-demo-custom-trigger .trigger {
  font-size: 18px;
  line-height: 64px;
  padding: 0 24px;
  cursor: pointer;
  transition: color 0.3s;
}

#components-layout-demo-custom-trigger .trigger:hover {
  color: #1890ff;
}

#components-layout-demo-custom-trigger .logo {
  height: 32px;
  background: rgba(255, 255, 255, 0.2);
  margin: 16px;
}
</style>
