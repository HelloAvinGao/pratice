<template>
    <div v-bind:style="{ paddingTop: styles.AllmarginTops }">
        <div>
        <h2
            v-bind:style="{
            fontSize: styles.h2FontSize + 'px',
            color: styles.h2Color,
            }"
        >
            {{ $t("navbar.welcomeMsg") }}
        </h2>
        </div>
        <div id="loginForm">
            {{ message }}
            <a-form
                id="components-form-demo-normal-login"
                :form="form"
                class="login-form"
                @submit="handleSubmit"
            >
                <a-form-item>
                <a-input
                    v-decorator="[
                    'userName',
                    { rules: [{ required: true, message: inputUserNameAlert }] },
                    ]"
                    :placeholder="$t('navbar.inputUserNameAlert')"
                >
                    <a-icon slot="prefix" type="user" style="color: rgba(0,0,0,.25)" />
                </a-input>
                </a-form-item>
                <a-form-item>
                <a-input
                    v-decorator="[
                    'password',
                    { rules: [{ required: true, message: inputPwdAlert }] },
                    ]"
                    type="password"
                    :placeholder="$t('navbar.inputPwdAlert')"
                >
                    <a-icon slot="prefix" type="lock" style="color: rgba(0,0,0,.25)" />
                </a-input>
                </a-form-item>
                <a-form-item>
                <a-checkbox class="login-form-rememberpwd"
                    v-decorator="[
                    'remember',
                    {
                        valuePropName: 'checked',
                        initialValue: true,
                    },
                    ]"
                >
                   {{ $t("navbar.remember") }}
                </a-checkbox>
                <a class="login-form-forgot" href="javascript:alert('请联系管理员!')">
                    {{ $t("navbar.forgetpwd") }}
                </a>
                <a-button type="primary" html-type="submit" class="login-form-button">
                    {{ $t("navbar.login") }}
                </a-button>
                
                <a href="javascript:alert('没有添加此功能!')"  id="registerstyle">
                    <!-- <router-link to="/register"> -->
                        {{ $t("navbar.register") }}!
                    <!-- </router-link> -->
                </a>
                <p class="login-form-langs" @click="changeLang()">
                    {{ $t("language.name") }}
                </p>
                </a-form-item>
            </a-form>
        </div>
    </div>
</template>
<script>
// import { mapMutations } from 'vuex';
export default {
  beforeCreate() {
    this.form = this.$form.createForm(this, { name: "normal_login" });
  },
  name: "Content", 
  data() {
    return {
      styles: {
        h2FontSize: "35",
        h2Color: "#6da63d",
        AllmarginTops: "10vh",
      },
      message: "",
      inputUserNameAlert:"请输入用户名!",
      inputPwdAlert:"请输入密码!"
    };
  },
  methods: {
    // ...mapMutations(['changeLogin']),
    changeLang: function() {
      let locale = localStorage.getItem("language") || "zh";
      let temp = locale === "zh" ? "en" : "zh";
      this.$i18n.locale = temp; //改变当前语言
      localStorage.language = temp;
      console.log(locale)
      if(locale == "zh"){
        this.inputUserNameAlert = 'Please input your username!'
        this.inputPwdAlert = 'Please input your username!'
      }else{
        this.inputUserNameAlert = '请输入用户名!'
        this.inputPwdAlert = '请输入密码!'
      }
      this.form = this.$form.createForm(this, { name: "normal_login" });
      // location.reload();
    },
    handleSubmit(e) {
      // let _this = this;
      e.preventDefault();
      this.form.validateFields((err, values) => {
        if (!err) {
          this.axios({
            url: "http://127.0.0.1:5000/login",
            method: "POST",
            crossdomain: true,
            params: values,
          }).then((res) => {
            if (res.data.message == 'success'){
              this.token = res.data.token;
              if (this.token) {
                this.$store.commit("set_token", this.token); //调用store中的获取token方法，并将token存在store中
                localStorage.setItem('username', JSON.stringify(this.token.username));
                this.$router.push({path:"/"});
              } else {
                this.$router.replace("/login");
              }
            }else if (res.data.message == 'failed'){
              if (localStorage.getItem('language') == 'zh'){
                this.message = "用户名或密码错误，请重新输入！"
              }else{
                this.message = "The username or password is error，Please input it again!"
              }
              this.$router.replace("/login");
            }else if (res.data.message == 'pass'){
              this.$router.push({name:"index",params: this.token});
            }else{
              console.log('The system is error!')
            }
          });
        }
      });
    },
  },
};
</script>
<style>
#components-form-demo-normal-login .login-form {
  max-width: 300px;
}
#components-form-demo-normal-login .login-form-forgot,
.login-form-langs {
  float: right;
}
#components-form-demo-normal-login .login-form-button {
  width: 100%;
}
#loginForm {
  max-width: 20rem;
  margin: auto;
}
#registerstyle,
.login-form-rememberpwd {
  float: left;
}
</style>
